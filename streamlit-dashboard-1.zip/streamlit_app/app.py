import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import os
from datetime import datetime

st.set_page_config(page_title="صيانة الأجهزة - مرحلة الإسكان", page_icon="🖥", layout="wide")

# ---------- Palette (matches the control-room identity) ----------
NAVY = "#0F1E3D"
NAVY_2 = "#16294F"
TEAL = "#1FA089"
CORAL = "#FF6152"
AMBER = "#F5B942"
GREEN = "#36C08B"
LILAC = "#8C7AE6"
LIGHT_BG = "#EEF1F6"
MUTE = "#6E7787"

DATA_FILE = "devices.csv"
COLUMNS = ["name", "code", "device_type", "op_mode", "status", "efficiency", "fault", "notes"]

# ---------- Styling ----------
st.markdown(f"""
<style>
html, body, [class*="css"] {{
    direction: rtl;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}}
.stApp {{ background-color: {LIGHT_BG}; }}
.banner {{
    background: {NAVY};
    padding: 22px 20px;
    border-radius: 6px;
    text-align: center;
    margin-bottom: 4px;
}}
.banner h1 {{
    color: white; font-size: 26px; margin: 0; font-weight: 800;
}}
.accent {{ height: 4px; background: {TEAL}; border-radius: 2px; margin-bottom: 20px; }}
.hero {{
    background: {NAVY_2};
    border-radius: 8px;
    padding: 30px 10px;
    text-align: center;
    color: white;
}}
.hero .pct {{ font-size: 52px; font-weight: 800; }}
.hero .lbl {{ font-size: 13px; color: #cbd3e0; margin-top: 6px; }}
.kpi {{
    border-radius: 8px;
    padding: 14px 10px;
    text-align: center;
    color: white;
    height: 100%;
}}
.kpi .n {{ font-size: 24px; font-weight: 800; }}
.kpi .l {{ font-size: 11px; margin-top: 4px; opacity: 0.9; }}
.section-title {{
    font-weight: 800; color: {NAVY}; font-size: 16px; margin: 18px 0 8px;
}}
.badge {{
    font-style: italic; color: {MUTE}; font-size: 12px; text-align:center;
}}
div[data-testid="stForm"] {{
    background: white; border-radius: 8px; padding: 16px; border: 1px solid #e2e6ed;
}}
</style>
""", unsafe_allow_html=True)


def load_data():
    if os.path.exists(DATA_FILE):
        df = pd.read_csv(DATA_FILE)
        for c in COLUMNS:
            if c not in df.columns:
                df[c] = ""
        return df[COLUMNS]
    return pd.DataFrame(columns=COLUMNS)


def save_data(df):
    df.to_csv(DATA_FILE, index=False)


if "devices" not in st.session_state:
    st.session_state.devices = load_data()

df = st.session_state.devices

# ---------- Header ----------
st.markdown('<div class="banner"><h1>متابعة صيانة الأجهزة — مرحلة الإسكان</h1></div>', unsafe_allow_html=True)
st.markdown('<div class="accent"></div>', unsafe_allow_html=True)

# ---------- Hero + KPIs ----------
total = len(df)
ok_count = int((df["status"] == "شغال").sum()) if total else 0
bad_count = total - ok_count
avg_eff = round(df["efficiency"].astype(float).mean(), 1) if total and df["efficiency"].notna().any() else 0
low_eff = int((df["efficiency"].astype(float) < 50).sum()) if total else 0
pct = round((ok_count / total) * 100, 1) if total else 0

hero_color = GREEN if pct >= 80 else (AMBER if pct >= 50 else CORAL)
verdict = "✅ الوضع ممتاز" if pct >= 80 else ("🟡 يحتاج متابعة" if pct >= 50 else "🔴 يحتاج تدخل عاجل")

col_hero, col_kpis = st.columns([1.3, 2])
with col_hero:
    st.markdown(f"""
    <div class="hero" style="background:{hero_color if False else NAVY_2}; border-top: 6px solid {hero_color};">
        <div class="pct">{pct}%</div>
        <div class="lbl">نسبة إنجاز مرحلة الإسكان (أجهزة شغالة)</div>
        <div style="margin-top:10px; font-weight:700;">{verdict}</div>
    </div>
    """, unsafe_allow_html=True)

with col_kpis:
    k1, k2, k3, k4, k5 = st.columns(5)
    kpis = [
        (k1, "📦", total, "إجمالي الأجهزة", NAVY_2),
        (k2, "✅", ok_count, "شغالة", GREEN),
        (k3, "⚠", bad_count, "مش شغالة", CORAL),
        (k4, "⚡", f"{avg_eff}%", "متوسط الكفاءة", AMBER),
        (k5, "🔧", low_eff, "كفاءة أقل من 50%", LILAC),
    ]
    for col, icon, n, l, color in kpis:
        with col:
            st.markdown(f"""
            <div class="kpi" style="background:{color};">
                <div class="n">{icon} {n}</div>
                <div class="l">{l}</div>
            </div>
            """, unsafe_allow_html=True)

# ---------- Breakdown ----------
st.markdown('<div class="section-title">💻 التوزيع حسب نوع الجهاز ونوع التشغيل</div>', unsafe_allow_html=True)
b1, b2, b3, b4 = st.columns(4)
hp_count = int((df["device_type"] == "HP").sum()) if total else 0
lenovo_count = int((df["device_type"] == "Lenovo").sum()) if total else 0
fujitsu_count = int((df["op_mode"] == "Fujitsu").sum()) if total else 0
kodak_count = int((df["op_mode"] == "Kodak").sum()) if total else 0

for col, label, n, color in [(b1, "HP", hp_count, "#13715F"), (b2, "Lenovo", lenovo_count, LILAC),
                               (b3, "Fujitsu", fujitsu_count, NAVY_2), (b4, "Kodak", kodak_count, AMBER)]:
    with col:
        st.markdown(f"""
        <div class="kpi" style="background:{color};">
            <div class="n">{n}</div>
            <div class="l">{label}</div>
        </div>
        """, unsafe_allow_html=True)

# ---------- Charts ----------
st.markdown('<div class="section-title">📊 الرسومات البيانية</div>', unsafe_allow_html=True)
c1, c2 = st.columns(2)

with c1:
    if total:
        fig = go.Figure(data=[go.Pie(
            labels=["شغال", "مش شغال"], values=[ok_count, bad_count],
            marker=dict(colors=[GREEN, CORAL]), hole=0.45
        )])
        fig.update_layout(showlegend=True, margin=dict(t=10, b=10, l=10, r=10), height=320)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("لا يوجد بيانات بعد لعرض الرسم.")

with c2:
    if total:
        fig2 = go.Figure(data=[go.Bar(
            x=["HP", "Lenovo"], y=[hp_count, lenovo_count],
            marker_color=["#13715F", LILAC]
        )])
        fig2.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=320)
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("لا يوجد بيانات بعد لعرض الرسم.")

# ---------- Add device form ----------
st.markdown('<div class="section-title">➕ إضافة جهاز جديد</div>', unsafe_allow_html=True)
with st.form("add_device", clear_on_submit=True):
    fc1, fc2 = st.columns(2)
    with fc1:
        name = st.text_input("اسم / رقم الجهاز")
        device_type = st.selectbox("نوع الجهاز", ["HP", "Lenovo"])
        status = st.selectbox("الحالة", ["شغال", "مش شغال"])
        fault = st.text_input("العطل (لو فيه)")
    with fc2:
        code = st.text_input("كود داخلي (اختياري)")
        op_mode = st.selectbox("نوع التشغيل", ["Fujitsu", "Kodak"])
        efficiency = st.number_input("الكفاءة %", min_value=0, max_value=100, value=80)
        notes = st.text_area("ملاحظات")

    submitted = st.form_submit_button("إضافة الجهاز")
    if submitted:
        if not name.strip():
            st.error("لازم تكتب اسم الجهاز")
        else:
            new_row = pd.DataFrame([{
                "name": name, "code": code, "device_type": device_type, "op_mode": op_mode,
                "status": status, "efficiency": efficiency, "fault": fault, "notes": notes
            }])
            st.session_state.devices = pd.concat([st.session_state.devices, new_row], ignore_index=True)
            save_data(st.session_state.devices)
            st.success("تمت إضافة الجهاز")
            st.rerun()

# ---------- Device list with delete ----------
st.markdown('<div class="section-title">📋 قائمة الأجهزة</div>', unsafe_allow_html=True)
if total:
    for idx, row in df[::-1].iterrows():
        status_color = GREEN if row["status"] == "شغال" else CORAL
        with st.container():
            lc, rc = st.columns([5, 1])
            with lc:
                st.markdown(f"""
                <div style="background:white; border-right:4px solid {status_color}; border-radius:6px; padding:10px 14px; margin-bottom:6px;">
                    <b>{row['name']}</b> &nbsp; <span style="color:{MUTE}; font-size:12px;">#{row['code']}</span>
                    &nbsp;&nbsp; <span style="color:{status_color}; font-weight:700;">{row['status']}</span>
                    <div style="font-size:12px; color:{MUTE}; margin-top:4px;">
                        {row['device_type']} · {row['op_mode']} · الكفاءة {row['efficiency']}%
                    </div>
                    {f"<div style='color:{CORAL}; font-size:13px; margin-top:4px;'>⚠ {row['fault']}</div>" if str(row['fault']).strip() and str(row['fault']) != 'nan' else ""}
                    {f"<div style='color:{MUTE}; font-size:13px; font-style:italic; margin-top:2px;'>{row['notes']}</div>" if str(row['notes']).strip() and str(row['notes']) != 'nan' else ""}
                </div>
                """, unsafe_allow_html=True)
            with rc:
                if st.button("حذف", key=f"del_{idx}"):
                    st.session_state.devices = st.session_state.devices.drop(idx).reset_index(drop=True)
                    save_data(st.session_state.devices)
                    st.rerun()
else:
    st.info("لسه معملتش أي جهاز. ضيف أول جهاز من الفورم فوق.")

# ---------- Export ----------
st.markdown('<div class="section-title">⬇ تصدير للإرسال</div>', unsafe_allow_html=True)
if total:
    csv_bytes = df.to_csv(index=False).encode("utf-8-sig")
    st.download_button("تحميل نسخة Excel/CSV", data=csv_bytes,
                        file_name=f"صيانة-الاجهزة-{datetime.now().strftime('%Y-%m-%d')}.csv",
                        mime="text/csv")

st.markdown(f'<div class="badge">يتحدث تلقائيًا مع كل إضافة أو حذف لجهاز</div>', unsafe_allow_html=True)
